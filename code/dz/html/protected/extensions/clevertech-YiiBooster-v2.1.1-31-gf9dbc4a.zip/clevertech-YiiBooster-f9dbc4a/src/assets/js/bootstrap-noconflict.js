var bootstrapButton, bootstrapTooltip;

(function ($) {
    bootstrapButton = $.fn.button;
    bootstrapTooltip = $.fn.tooltip;
})(jQuery);